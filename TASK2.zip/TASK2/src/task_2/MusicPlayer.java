package task_2;

public interface MusicPlayer {
    void playMusic(String sourceDetails);
}
