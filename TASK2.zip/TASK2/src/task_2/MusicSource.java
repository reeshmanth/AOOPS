package task_2;

public interface MusicSource {
    String getSourceName();
    String getSourceDetails();
}
