package game;

public class Skeleton extends Enemy {
    public void attack() {
        System.out.println("Skeleton shoots an arrow!");
    }

    public void display() {
        System.out.println("A Skeleton has appeared!");
    }
}
