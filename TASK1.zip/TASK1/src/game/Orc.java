package game;

public class Orc extends Enemy {
    public void attack() {
        System.out.println("Orc slashes with an axe!");
    }

    public void display() {
        System.out.println("An Orc has appeared!");
    }
}
