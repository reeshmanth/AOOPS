package game;

public class MagicWand implements Weapon {
    public void use() {
        System.out.println("Casting a spell with a magic wand!");
    }

    public void display() {
        System.out.println("A Magic Wand has been equipped!");
    }
}
