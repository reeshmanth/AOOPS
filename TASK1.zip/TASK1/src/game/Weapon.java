package game;

public interface Weapon {
    void use();
    void display();
}
